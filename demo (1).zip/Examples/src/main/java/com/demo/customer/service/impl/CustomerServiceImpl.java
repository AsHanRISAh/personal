package com.demo.customer.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.customer.entity.Customer;
import com.demo.customer.repositary.CustomerRepository;
import com.demo.customer.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	CustomerRepository customerRepository;

	@Override
	public Customer saveCustomer(Customer customer) {
		Customer customerCheck =customerRepository.findByEmail(customer.getEmail());
		if(customerCheck !=null)
		{
			return null;
		}
		return customerRepository.save(customer);
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return customerRepository.findAll();
	}

	@Override
	public Customer getCustomer(int id) {
		// TODO Auto-generated method stub
		Optional<Customer> customer= customerRepository.findById(id);
		if(customer.isPresent())
		{
			return customer.get();
		}
		return null;
	}

	@Override
	public void deleteCustomer(int id) {
		// TODO Auto-generated method stub
		customerRepository.deleteById(id);
	}

	@Override
	public Customer updateCustomer(int id,Customer customer) {
		// TODO Auto-generated method stub
		Customer customerdb= getCustomer(id);
		customerdb.setFirstName(customer.getFirstName());
		customerdb.setLastName(customer.getLastName());
		customerdb.setAge(customer.getAge());
		customerdb.setEmail(customer.getEmail());
		customerdb.setPhoneNumber(customer.getPhoneNumber());
		
		return saveCustomer(customerdb);
	}
	
	@Override
    public List<Customer> getCustomerByFirstName(String firstName) {
        // TODO Auto-generated method stub
        List<Customer> customerByFirstName=customerRepository.findByFirstName(firstName);
        return customerByFirstName;
    }

 

    @Override
    public List<Customer> getCustomerByFirstNameOrAge(String firstName, int age) {
        // TODO Auto-generated method stub
        List<Customer> customerByFirstNameorAge=customerRepository.findByFirstNameOrAge(firstName,age);
        return customerByFirstNameorAge;
    }

 

    @Override
    public List<Customer> getCustomersByFirstNameAndLastName(String firstName, String lastName) {
        // TODO Auto-generated method stub
        List<Customer> customerByFirstNameAndLastName=customerRepository.getCustomersByFirstNameAndLastName(firstName,lastName);
        return customerByFirstNameAndLastName;
    }

	@Override
	public String customerLogin(String email, String password) {
		// TODO Auto-generated method stub
		//Customer customer1=new Customer();
		if(email==null && password==null)
		{
			return "incorrect login";
		}
		
		return "Login successfull";
	}

}
