package com.demo.customer.service;

import java.util.List;

import com.demo.customer.entity.Customer;

public interface CustomerService {


	List<Customer> getAllCustomer();

	Customer saveCustomer(Customer customer);

	Customer getCustomer(int id);

	void deleteCustomer(int id);

	Customer updateCustomer(int id,Customer customer);

	List<Customer> getCustomerByFirstName(String firstName);

	List<Customer> getCustomerByFirstNameOrAge(String firstName, int age);

	List<Customer> getCustomersByFirstNameAndLastName(String firstName, String lastName);

	String customerLogin(String email, String password);

	

}
