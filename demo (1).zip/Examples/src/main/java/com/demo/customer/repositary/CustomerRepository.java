package com.demo.customer.repositary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.demo.customer.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

	List<Customer> findByFirstName(String firstName);

	List<Customer> findByFirstNameOrAge(String firstName, int age);

	@Query("from Customer c where c.firstName=:firstName and c.lastName=:lastName")
	List<Customer> getCustomersByFirstNameAndLastName(@Param("firstName") String firstName, @Param("lastName") String lastName);

	Customer findByEmail(String email);

}
