package com.demo.customer.service.impl;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.customer.entity.TrainDetails;
import com.demo.customer.repositary.TrainDetailsRepository;
import com.demo.customer.service.TrainDetailsService;

@Service
public class TrainDetailsServiceImpl implements TrainDetailsService{
	
	@Autowired
	TrainDetailsRepository trainDetailsRepository;

	@Override
	public List<TrainDetails> getTrainDetails(String source, String destination) {
		// TODO Auto-generated method stub
		List<TrainDetails> getTrainDetail=trainDetailsRepository.getBySourceAndDestination(source,destination);
		return getTrainDetail;
	}

	@Override
	public TrainDetails saveTrainDetails(TrainDetails trainDetails) {
		// TODO Auto-generated method stub
		return trainDetailsRepository.save(trainDetails);
	}

}
