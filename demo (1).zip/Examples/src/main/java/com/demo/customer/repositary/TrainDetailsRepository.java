package com.demo.customer.repositary;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.demo.customer.entity.TrainDetails;

public interface TrainDetailsRepository extends JpaRepository<TrainDetails, Integer> {

	
	@Query("from TrainDetails t where t.source=:source and t.destination=:destination")
	List<TrainDetails> getBySourceAndDestination(@Param("source") String source,@Param("destination") String destination);

}
