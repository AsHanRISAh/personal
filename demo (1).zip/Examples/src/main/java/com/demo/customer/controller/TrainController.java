package com.demo.customer.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.customer.entity.Customer;
import com.demo.customer.entity.TrainDetails;
import com.demo.customer.service.TrainDetailsService;

@RestController
@RequestMapping("/trains")
public class TrainController {
	
	@Autowired
	TrainDetailsService trainDetailsService;
	
	@PostMapping()
	public TrainDetails saveTrainDetails(@RequestBody TrainDetails trainDetails) {
		trainDetailsService.saveTrainDetails(trainDetails);
		return trainDetails;
	}
	
	@GetMapping("/trains")
	public List<TrainDetails> getTrainDetails(@RequestParam String source,@RequestParam String destination){
		return trainDetailsService.getTrainDetails(source,destination);
	}

}
