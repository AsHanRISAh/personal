package com.demo.customer.service;

import java.sql.Date;
import java.util.List;

import com.demo.customer.entity.TrainDetails;

public interface TrainDetailsService {

	List<TrainDetails> getTrainDetails(String source, String destination);

	TrainDetails saveTrainDetails(TrainDetails trainDetails);

}
