package com.trains.service;

import java.util.Date;
import java.util.List;

import com.trains.dto.TrainDetailsDto;
import com.trains.entity.TrainDetails;

public interface TrainDetailsService {

	List<TrainDetails> getTrainDetails(String source, String destination,Date date);

	TrainDetailsDto saveTrainDetails(TrainDetailsDto trainDetailsDto);

}
