package com.trains.service;

import com.trains.dto.BookingDetailsDto;

public interface BookingDetailsService {

	String bookTicket(BookingDetailsDto bookingDetails);

	BookingDetailsDto getHistory(int userId);

}
