package com.trains.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trains.dto.BookingDetailsDto;
import com.trains.dto.PassengerDto;
import com.trains.entity.BookingDetails;
import com.trains.entity.Customer;
import com.trains.entity.Passenger;
import com.trains.entity.TrainDetails;
import com.trains.repositary.BookingDetailsRepository;
import com.trains.repositary.PassengerRepository;
import com.trains.repositary.TrainDetailsRepository;
import com.trains.service.BookingDetailsService;


@Service
public class BookingDetailsServiceImpl implements BookingDetailsService {

	@Autowired
	TrainDetailsRepository trainDetailsRepository;
	@Autowired
	BookingDetailsRepository bookingDetailsRepository;
	@Autowired
	PassengerRepository passengerRepository;
	
	@Override
	public String bookTicket(BookingDetailsDto bookingDetails) {
		TrainDetails trainDet = trainDetailsRepository.findByTrainIdAndDate(bookingDetails.getTrainId(), bookingDetails.getJourneyDate());
		if(trainDet != null) {
			if(bookingDetails.getTotalNoSeats() <= trainDet.getAvailableSeats()) {
				bookingDetails.setTotalPrice(bookingDetails.getTicketPrice()*bookingDetails.getTotalNoSeats());
				String uniqueKey = UUID.randomUUID().toString();
				bookingDetails.setTicketNumber(uniqueKey);
				
				BookingDetails details = new BookingDetails();
				BeanUtils.copyProperties(bookingDetails, details);
				bookingDetailsRepository.save(details);
				
				trainDet.setAvailableSeats(trainDet.getAvailableSeats()-bookingDetails.getTotalNoSeats());
				trainDetailsRepository.save(trainDet);
				Customer customer=new Customer();
				for(PassengerDto dto : bookingDetails.getPassengerList()) {
					dto.setUserId(customer.getId());
					Passenger passengerList = new Passenger();
					BeanUtils.copyProperties(dto, passengerList);
					passengerRepository.save(passengerList);
				}
				return "SUCCESS";
			} else {
				return "No Seats Available";
			}
		}
		return "No Train Available";
	}
	
	@Override
	public BookingDetailsDto getHistory(int userId) {
		BookingDetailsDto bookDetailsDto = new BookingDetailsDto();
		List<PassengerDto> listDto =  new ArrayList<>();
		BookingDetails bookDet = bookingDetailsRepository.findByUserId(userId);
		List<Passenger> passengerList = passengerRepository.findByUserId(userId);
		
		BeanUtils.copyProperties(bookDet, bookDetailsDto);
		for(Passenger dto : passengerList) {
			
			PassengerDto passengerListDto = new PassengerDto();
			BeanUtils.copyProperties(dto, passengerListDto);
			listDto.add(passengerListDto);
		}
		bookDetailsDto.setUserList(listDto);
		
		return bookDetailsDto;
	}

}
