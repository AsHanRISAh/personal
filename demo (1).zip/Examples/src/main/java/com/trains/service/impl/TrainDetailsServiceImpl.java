package com.trains.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trains.dto.TrainDetailsDto;
import com.trains.entity.TrainDetails;
import com.trains.repositary.TrainDetailsRepository;
import com.trains.service.TrainDetailsService;

@Service
public class TrainDetailsServiceImpl implements TrainDetailsService{
	
	@Autowired
	TrainDetailsRepository trainDetailsRepository;

	@Override
	public List<TrainDetails> getTrainDetails(String source, String destination,Date date) {
		// TODO Auto-generated method stub

		List<TrainDetails> getTrainDetail=trainDetailsRepository.findBySourceAndDestinationAndDate(source, destination, date);
		return getTrainDetail;
	}

	@Override
	public TrainDetailsDto saveTrainDetails(TrainDetailsDto trainDetailsDto) {
		// TODO Auto-generated method stub
		TrainDetails trainDetails=new TrainDetails();
		BeanUtils.copyProperties(trainDetailsDto, trainDetails);
		trainDetailsRepository.save(trainDetails);
		return trainDetailsDto;
	}

}
