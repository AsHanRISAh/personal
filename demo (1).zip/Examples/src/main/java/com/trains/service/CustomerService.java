package com.trains.service;

import java.util.List;

import com.trains.dto.CustomerDto;
import com.trains.entity.Customer;

public interface CustomerService {


	List<Customer> getAllCustomer();

	CustomerDto saveCustomer(CustomerDto customerDto);
	CustomerDto updateCustomer(int id,CustomerDto customerDto);

	Customer getCustomer(int id);

	void deleteCustomer(int id);

	//Customer updateCustomer(int id,Customer customer);

	List<Customer> getCustomerByFirstName(String firstName);

	List<Customer> getCustomerByFirstNameOrAge(String firstName, int age);

	List<Customer> getCustomersByFirstNameAndLastName(String firstName, String lastName);

	String customerLogin(String email, String password);

	

}
