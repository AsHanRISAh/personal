package com.trains.service.impl;

import java.util.List;
import java.util.Optional;

import javax.swing.text.DefaultEditorKit.CutAction;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trains.dto.CustomerDto;
import com.trains.entity.Customer;
import com.trains.repositary.CustomerRepository;
import com.trains.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	CustomerRepository customerRepository;

	
	
	@Override
	public CustomerDto saveCustomer(CustomerDto customerDto) {
		Customer customer =new Customer();
		BeanUtils.copyProperties(customerDto, customer);
		Customer customerCheck =customerRepository.findByEmail(customer.getEmail());
		if(customerCheck !=null)
		{
			return null;
		}
		customerRepository.save(customer);
		return customerDto;
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return customerRepository.findAll();
	}

	@Override
	public Customer getCustomer(int id) {
		// TODO Auto-generated method stub
		Optional<Customer> customer= customerRepository.findById(id);
		if(customer.isPresent())
		{
			return customer.get();
		}
		return null;
	}

	@Override
	public void deleteCustomer(int id) {
		// TODO Auto-generated method stub
		customerRepository.deleteById(id);
	}

	@Override
	public CustomerDto updateCustomer(int id,CustomerDto customerDto) {
		// TODO Auto-generated method stub
		Customer customerdb= getCustomer(id);
		customerdb.setFirstName(customerDto.getFirstName());
		customerdb.setLastName(customerDto.getLastName());
		customerdb.setAge(customerDto.getAge());
		customerdb.setEmail(customerDto.getEmail());
		customerdb.setPhoneNumber(customerDto.getPhoneNumber());
		
		customerRepository.save(customerdb);
		return customerDto;
	}
	
	
	@Override
    public List<Customer> getCustomerByFirstName(String firstName) {
        // TODO Auto-generated method stub
        List<Customer> customerByFirstName=customerRepository.findByFirstName(firstName);
        return customerByFirstName;
    }

 

    @Override
    public List<Customer> getCustomerByFirstNameOrAge(String firstName, int age) {
        // TODO Auto-generated method stub
        List<Customer> customerByFirstNameorAge=customerRepository.findByFirstNameOrAge(firstName,age);
        return customerByFirstNameorAge;
    }

 

    @Override
    public List<Customer> getCustomersByFirstNameAndLastName(String firstName, String lastName) {
        // TODO Auto-generated method stub
        List<Customer> customerByFirstNameAndLastName=customerRepository.getCustomersByFirstNameAndLastName(firstName,lastName);
        return customerByFirstNameAndLastName;
    }

	@Override
	public String customerLogin(String email, String password) {
		// TODO Auto-generated method stub
		Customer customer=customerRepository.findByEmailAndPassword(email,password);
		if(customer!=null)
		{
			return " login";
		}
		
		return "Login unsuccessfull";
	}

}
