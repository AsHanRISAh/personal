package com.trains.repositary;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.trains.entity.TrainDetails;

public interface TrainDetailsRepository extends JpaRepository<TrainDetails, Integer> {

	
	/*
	 * @Query("from TrainDetails t where t.source=:source and t.destination=:destination"
	 * ) List<TrainDetails> getBySourceAndDestination(@Param("source") String
	 * source,@Param("destination") String destination);
	 */

	List<TrainDetails> findBySourceAndDestinationAndDate(String source,String destination,Date date);

	TrainDetails findByTrainIdAndDate(int trainId, Date journeyDate);

}
