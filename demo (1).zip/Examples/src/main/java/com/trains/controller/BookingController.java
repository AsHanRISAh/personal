package com.trains.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.trains.dto.BookingDetailsDto;
import com.trains.dto.PassengerDto;
import com.trains.service.BookingDetailsService;

@RestController
@RequestMapping("/books")
public class BookingController {
	
	@Autowired
	BookingDetailsService bookingDetailsService;

	@PostMapping("/ticket")
	public String bookTrain(@RequestBody BookingDetailsDto bookingDetails) {
		String response = bookingDetailsService.bookTicket(bookingDetails);
		return response;
	}
	
	@GetMapping("/history/{userId}")
	public BookingDetailsDto getHistory(@PathVariable int userId) {
		return bookingDetailsService.getHistory(userId);
		
	}
}