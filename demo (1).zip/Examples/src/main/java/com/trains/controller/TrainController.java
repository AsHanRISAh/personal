package com.trains.controller;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.trains.dto.TrainDetailsDto;
import com.trains.entity.TrainDetails;
import com.trains.service.TrainDetailsService;

@RestController
@RequestMapping("/trains")
public class TrainController {
	
	@Autowired
	TrainDetailsService trainDetailsService;
	
	@PostMapping("/save")
	public TrainDetailsDto saveTrainDetails(@RequestBody TrainDetailsDto trainDetailsDto) {
		trainDetailsService.saveTrainDetails(trainDetailsDto);
		return trainDetailsDto;
	}
	
	@GetMapping("/trains")
	public List<TrainDetails> getTrainDetails(@Valid @Pattern(regexp = "[a-z]||[A-Z]") @RequestParam String source,@Pattern(regexp = "[a-z]") @RequestParam String destination, @Pattern(regexp = "[0-9]{4}-[0-9]{2}-[0-9]{2}")@RequestParam @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) Date date){
		return trainDetailsService.getTrainDetails(source,destination,date);
	}

	

}
