package com.trains.dto;

import java.util.Date;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.format.annotation.DateTimeFormat;

public class BookingDetailsDto {

	private int id;
	private int trainId;
	private String ticketNumber;
	private int userId;
	@CreationTimestamp
	private Date bookingDate;
	@DateTimeFormat(iso=DateTimeFormat.ISO.DATE)
	private Date journeyDate;
	private int ticketPrice;
	private int totalPrice;
	private String source;
	private String destination;
	private int totalNoSeats;
	
	private List<PassengerDto> passengerList;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getTrainId() {
		return trainId;
	}
	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}
	public String getTicketNumber() {
		return ticketNumber;
	}
	public void setTicketNumber(String ticketNumber) {
		this.ticketNumber = ticketNumber;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public Date getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}
	public Date getJourneyDate() {
		return journeyDate;
	}
	public void setJourneyDate(Date journeyDate) {
		this.journeyDate = journeyDate;
	}
	public int getTicketPrice() {
		return ticketPrice;
	}
	public void setTicketPrice(int ticketPrice) {
		this.ticketPrice = ticketPrice;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getTotalNoSeats() {
		return totalNoSeats;
	}
	public void setTotalNoSeats(int totalNoSeats) {
		this.totalNoSeats = totalNoSeats;
	}
	public List<PassengerDto> getPassengerList() {
		return passengerList;
	}
	public void setUserList(List<PassengerDto> passengerList) {
		this.passengerList = passengerList;
	}
	@Override
	public String toString() {
		return "BookDetailsDto [id=" + id + ", trainId=" + trainId + ", ticketNumber=" + ticketNumber + ", userId="
				+ userId + ", bookingDate=" + bookingDate + ", journeyDate=" + journeyDate + ", ticketPrice="
				+ ticketPrice + ", totalPrice=" + totalPrice + ", source=" + source + ", destination=" + destination
				+ ", totalNoSeats=" + totalNoSeats + ", passengerList=" + passengerList + "]";
	}
}
	